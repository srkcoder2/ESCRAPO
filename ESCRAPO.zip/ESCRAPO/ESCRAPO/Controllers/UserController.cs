﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ESCRAPO.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ESCRAPO.Controllers
{
    public class UserController : Controller
    {
        #region default
        private readonly ESCRAPODbContext escDb;

        private readonly IWebHostEnvironment henv;


        public UserController(ESCRAPODbContext escDB, IWebHostEnvironment henv)
        {
            escDb = escDB;
            this.henv = henv;
        }
        #endregion default
        //------put it in every new controller ends---

        public IActionResult UserHome(int Pid)
        {
            HttpContext.Session.SetString("Perid", Convert.ToString(Pid));
            return View();
        }
        public IActionResult UserHelp()
        {
            return View();
        }
        [HttpGet]
        public IActionResult UserComplain()
        {
            return View();
        }
        [HttpPost]
        public IActionResult UserComplain(IFormCollection frm)
       {
           
            ComplainMaster complainmaster = new ComplainMaster();
            complainmaster.Pid = Convert.ToInt32(HttpContext.Session.GetString("Perid"));
            complainmaster.ComplainDesc = Convert.ToString(frm["Cdetails"]);
            escDb.ComplainMasters.Add(complainmaster);
            escDb.SaveChanges();
            return RedirectToAction("UserComplainPost");

        }


        [HttpGet]
        public IActionResult  UserComplainPost()
        {
            return View();
        }

        [HttpPost]
        [ActionName("UserComplainPost")]
        public IActionResult UserComplainSubmit()
        {
            var perId = HttpContext.Session.GetString("Perid");
            return RedirectToAction("UserHome",new { Pid = Convert.ToInt32(perId) });
        }



        [HttpGet]
        public IActionResult UserFeedback()
        {
            var usrId = HttpContext.Session.GetString("Perid");
            //var usrRec = escDb.PersonMasters.Where
            //    (q => q.Pid == Convert.ToInt32(usrId)).FirstOrDefault();
            //TempData["perName"] = usrRec.Pname;
            return View();
        }

        [HttpPost]
        public JsonResult UserFeedback(string comments, string rdchk)
        {
            FeedbackMaster feedbackmaster = new FeedbackMaster();
            feedbackmaster.FeedbackDesc = comments;
            feedbackmaster.FeedbackDateTime = DateTime.Now.ToString();
            feedbackmaster.FeedbackExperience = rdchk;
            escDb.FeedbackMasters.Add(feedbackmaster);
            escDb.SaveChanges();
            return Json("Success");            
        }

        [HttpGet]
        public IActionResult UserFeedbackPost()
        {
            return View();
        }

        [HttpPost]
        [ActionName("UserFeedbackPost")]
        public IActionResult UserFeedbackSubmit()
        {
            var perId = HttpContext.Session.GetString("Perid");
            return RedirectToAction("UserHome", new { Pid = Convert.ToInt32(perId) });
        }


        #region SellEwaste

        public IActionResult UserViewMainCatDetails()
        {
            var mainCatList = escDb.ProductCategoryMasters.ToList();

            var perId = HttpContext.Session.GetString("Perid");
            //   return RedirectToAction("mainCatList", new { Pid = Convert.ToInt32(perId) });
            return View(mainCatList);    
        }

        public IActionResult UserViewSubCatDetails(int Catid)
        {
            HttpContext.Session.SetString("Catid", Catid.ToString());
            var subCatList = escDb.ProductSubCategoriesMasters.Where(q => q.Catid == Catid).ToList();
            return View(subCatList);
        }

        #endregion



        #region cart
        [HttpGet]
        public IActionResult UserViewAddtoCart(int SCid)
        {
            HttpContext.Session.SetString("SCid", SCid.ToString());
            TempData["SCid"] = SCid;
            var cartList = escDb.ProductSubCategoriesMasters.Where(q => q.SCid == SCid).ToList();
            return View(cartList);

        } 
        
        [HttpPost]
        public IActionResult UserViewAddtoCart(IFormCollection frm)
        {
           AddtoCartMaster atc =new AddtoCartMaster();
            atc.Uid = Convert.ToInt32(HttpContext.Session.GetString("Perid"));
            atc.SCid = Convert.ToInt32(frm["Scid"]);
            atc.SCqty = Convert.ToInt32(frm["SCqty"]);
            var Catid= HttpContext.Session.GetString("Catid");
            escDb.AddtoCartMasters.Add(atc);
            escDb.SaveChanges();
            return RedirectToAction("UserViewSubCatDetails", new { Catid = Convert.ToInt32(Catid)  });

            

        }

        #endregion cart
        public IActionResult UserLogout()
        {
            return RedirectToAction("Home", "Login");
        }



    }
}
