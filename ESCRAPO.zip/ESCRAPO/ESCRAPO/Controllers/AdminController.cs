﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ESCRAPO.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ESCRAPO.Controllers
{
    public class AdminController : Controller
    {

        //------put it in every new controller starts---
        #region default
        private readonly ESCRAPODbContext escDb;

        private readonly IWebHostEnvironment henv;


        public AdminController(ESCRAPODbContext escDB, IWebHostEnvironment henv)
        {
            escDb = escDB;
            this.henv = henv;
        }
        #endregion default
        //------put it in every new controller ends---


        public IActionResult AdminHome(int Pid)
        {
            HttpContext.Session.SetString("adminId", Pid.ToString());
            return View();
        }

        public IActionResult AdminViewComplainDetails()
        {
            var complainList = escDb.ComplainMasters.ToList();
            return View();
        }
        #region AreaDetails
        public IActionResult AdminViewAreaDetails()
        {
            var areaList = escDb.AreaMasters.ToList();
            return View(areaList);
        }

        [HttpGet]
        public IActionResult AdminAddorEditArea(int Aid = 0)
        {
            if (Aid == 0) //Adding a new Area
            {
                return View(new AreaMaster());
            }
            else //Editing an existing record
            {
                var areaRec = escDb.AreaMasters.Where(am => am.Aid == Aid).FirstOrDefault();
                return View(areaRec);
            }
        }


        [HttpPost]
        public IActionResult AdminAddorEditArea(AreaMaster areamaster)
        {
            if (areamaster.Aid == 0) //Adding a new Area
            {
                escDb.AreaMasters.Add(areamaster);
                escDb.SaveChanges();
                return RedirectToAction("AdminViewAreaDetails");
            }
            else //Editing an existing record
            {
                escDb.Entry(areamaster).State = EntityState.Modified;
                escDb.SaveChanges();
                return RedirectToAction("AdminViewAreaDetails");
            }
        }
        //[HttpGet]
        //public IActionResult AdminAddArea()
        //{
        //    return View();            
        //}

        //[HttpPost]
        //public IActionResult AdminAddArea(AreaMaster areamaster)
        //{
        //    escDb.AreaMasters.Add(areamaster);
        //    escDb.SaveChanges();
        //    return RedirectToAction("AdminViewAreaDetails");
        //}

        //[HttpGet]
        //public IActionResult AdminEditArea(int Aid)
        //{
        //    var areaRec = escDb.AreaMasters.Where(am => am.Aid == Aid).FirstOrDefault();
        //    return View(areaRec);
        //}
        //[HttpPost]
        //public IActionResult AdminEditArea(AreaMaster areamaster)
        //{
        //    escDb.Entry(areamaster).State = EntityState.Modified;
        //    escDb.SaveChanges();
        //    return RedirectToAction("AdminViewAreaDetails");
        //}
        public IActionResult AdminRemoveArea(int Aid)
        {
            var removeArea = escDb.AreaMasters.Where(am => am.Aid == Aid).FirstOrDefault();
            escDb.Entry(removeArea).State = EntityState.Deleted;
            escDb.SaveChanges();
            return RedirectToAction("AdminViewAreaDetails");
        }
        #endregion AreaDetails

        public IActionResult AdminViewTransporterDetails()
        {
            var trsList = escDb.PersonMasters.Where(pm => pm.Proleid == 3).ToList();
            return View(trsList);

        }

        public IActionResult AdminViewUserDetails()
        {
            var userList = escDb.PersonMasters.Where(us => us.Proleid == 2).ToList();
            return View(userList);
        }

        public IActionResult AdminViewDriverDetails(int Pid)
        {
            var drvList = escDb.DriverMasters.Where(dv => dv.TransId == Pid).ToList();
            return View(drvList);
        }

        #region subcat

        [HttpGet]
        public IActionResult AdminSubcatAddorViewDetails(int Catid)
        {
            var subcatList = escDb.ProductSubCategoriesMasters.Where(q => q.Catid == Catid).ToList();
            //var caList = escDb.ProductCategoryMasters.ToList();
            //ViewBag.caList = subcatList;
            TempData["catid"] = Catid;
            return View(subcatList);
        }

        //[HttpPost]
        //public IActionResult AdminSubcatAddorViewDetails(IFormCollection frm, IFormFile SubImg, ProductSubCategoriesMasters productmaster)
        //{
        //    string uniqueImageName = null;
        //    if (SubImg != null)
        //    {
        //        // C: \Users\RiyaSoni\source\repos\ESCRAPO\ESCRAPO\wwwroot\
        //        string uploadimgfoldername = Path.Combine(henv.WebRootPath, "images\\productlist\\EWasteSubCatList\\");
        //        uniqueImageName = Guid.NewGuid().ToString() + "_" + SubImg.FileName;
        //        string finalPath = Path.Combine(uploadimgfoldername, uniqueImageName);
        //        SubImg.CopyTo(new FileStream(finalPath, FileMode.Create));
        //    }
        //    productmaster.SCimage = "images\\productlist\\EWasteSubCatList\\" + uniqueImageName;

        //    escDb.ProductSubCategoriesMasters.Add(productmaster);
        //    escDb.SaveChanges();
        //    return RedirectToAction("AdminSubcatAddorViewDetails");

        //}

        [HttpGet]
        public IActionResult AddSubcat(int Catid)
        {
            TempData["catid"] = Catid;         
            return View();
        }


        [HttpPost]
        public IActionResult AddSubcat(IFormCollection frm, IFormFile SubImg, int Catid)
        {
            ProductSubCategoriesMasters prodscmaster = new ProductSubCategoriesMasters();
            prodscmaster.Catid = Convert.ToInt32(TempData["catid"]);
            prodscmaster.SCimage = Convert.ToString(frm["scimage"]);
            prodscmaster.SCid = Convert.ToInt32(TempData["scid"]);
            prodscmaster.SCname = Convert.ToString(frm["scname"]);
            prodscmaster.SCpriceperunit = Convert.ToInt32(TempData["scperunit"]);
            prodscmaster.SCDesc = Convert.ToString(frm["scdesc"]);
                


            string uniqueImageName = null;
            if (SubImg != null)
            {

                string uploadimgfoldername = Path.Combine(henv.WebRootPath, "images\\productlist\\EwasteSubCatList\\");
                uniqueImageName = Guid.NewGuid().ToString() + "_" + SubImg.FileName;
                string finalPath = Path.Combine(uploadimgfoldername, uniqueImageName);
                SubImg.CopyTo(new FileStream(finalPath, FileMode.Create));
            }
            prodscmaster.SCimage = "images\\productlist\\EwasteSubCatList\\" + uniqueImageName;

            var aaList = escDb.ProductSubCategoriesMasters.Where(sc => sc.Catid == Catid);
            escDb.ProductSubCategoriesMasters.Add(prodscmaster);
            escDb.SaveChanges();
            return RedirectToAction("AdminSubcatAddorViewDetails");
        }

        [HttpGet]
        public IActionResult SCEdit(int SCid)
        {
            var sc = escDb.ProductSubCategoriesMasters.Where(sm => sm.SCid == SCid).FirstOrDefault();
            return View(sc);
        }

        [HttpPost]
        public IActionResult SCEdit(ProductSubCategoriesMasters ps, IFormCollection frm, IFormFile SubImg)
        {
            ps.SCid = Convert.ToInt32(frm["aalist"]);
            string uniqueImageName = null;
            if (SubImg != null)
            {
                // C: \Users\RiyaSoni\source\repos\ESCRAPO\ESCRAPO\wwwroot\
                string uploadimgfoldername = Path.Combine(henv.WebRootPath, "images\\productlist\\EwasteSubCatList\\");
                uniqueImageName = Guid.NewGuid().ToString() + "_" + SubImg.FileName;
                string finalPath = Path.Combine(uploadimgfoldername, uniqueImageName);
                SubImg.CopyTo(new FileStream(finalPath, FileMode.Create));
            }
            ps.SCimage = "images\\productlist\\EwasteSubCatList\\" + uniqueImageName;


            escDb.Entry(ps).State = EntityState.Modified;
            escDb.SaveChanges();
            return RedirectToAction("AdminSubcatAddorViewDetails");

        }


        public IActionResult SCRemove(int SCid)
        {

            var removes = escDb.ProductSubCategoriesMasters.Where(sm => sm.SCid == SCid).FirstOrDefault();
            escDb.Entry(removes).State = EntityState.Deleted;
            escDb.SaveChanges();
            return RedirectToAction("AdminSubcatAddorViewDetails");
        }

    #endregion subcat

    #region maincat
    public IActionResult AdminViewMainCatDetails()
    {
        var catList = escDb.ProductCategoryMasters.ToList();
        return View(catList);

    }

    [HttpGet]
    public IActionResult Addcat()
    {
        var caList = escDb.ProductCategoryMasters.ToList();
        return View();
    }


    [HttpPost]
    public IActionResult Addcat(ProductCategoryMaster productmaster, IFormCollection frm, IFormFile MainImg)
    {
        productmaster.Catid = Convert.ToInt32(frm["calist"]);
        string uniqueImageName = null;
        if (MainImg != null)
        {
            // C: \Users\RiyaSoni\source\repos\ESCRAPO\ESCRAPO\wwwroot\
            string uploadimgfoldername = Path.Combine(henv.WebRootPath, "images\\productlist\\EWasteMainCatList\\");
            uniqueImageName = Guid.NewGuid().ToString() + "_" + MainImg.FileName;
            string finalPath = Path.Combine(uploadimgfoldername, uniqueImageName);
            MainImg.CopyTo(new FileStream(finalPath, FileMode.Create));
        }
        productmaster.Catimage = "images\\productlist\\EWasteMainCatList\\" + uniqueImageName;

        escDb.ProductCategoryMasters.Add(productmaster);
        escDb.SaveChanges();
        return RedirectToAction("AdminViewMainCatDetails");
    }


    [HttpGet]
    public IActionResult AdminEditCat(int Catid)
    {
        var cated = escDb.ProductCategoryMasters.Where(cm => cm.Catid == Catid).FirstOrDefault();
        return View(cated);
    }

    [HttpPost]
    public IActionResult AdminEditCat(ProductCategoryMaster productmaster, IFormCollection frm, IFormFile MainImg)
    {
        productmaster.Catid = Convert.ToInt32(frm["calist"]);
        string uniqueImageName = null;
        if (MainImg != null)
        {
            // C: \Users\RiyaSoni\source\repos\ESCRAPO\ESCRAPO\wwwroot\
            string uploadimgfoldername = Path.Combine(henv.WebRootPath, "images\\productlist\\EWasteMainCatList\\");
            uniqueImageName = Guid.NewGuid().ToString() + "_" + MainImg.FileName;
            string finalPath = Path.Combine(uploadimgfoldername, uniqueImageName);
            MainImg.CopyTo(new FileStream(finalPath, FileMode.Create));
        }
        productmaster.Catimage = "images\\productlist\\EWasteMainCatList\\" + uniqueImageName;

        escDb.Entry(productmaster).State = EntityState.Modified;
        escDb.SaveChanges();
        return RedirectToAction("AdminViewSubCatDetails");

    }

    public IActionResult AdminRemoveProduct(int Catid)
    {

        var removeCa = escDb.ProductCategoryMasters.Where(cm => cm.Catid == Catid).FirstOrDefault();
        escDb.Entry(removeCa).State = EntityState.Deleted;
        escDb.SaveChanges();
        return RedirectToAction("AdminViewMainCatDetails");
    }

    #endregion maincat
}


}
