﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ESCRAPO.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System.IO;

namespace ESCRAPO.Controllers
{
    public class LoginController : Controller
    {
        //------put it in every new controller starts---
        #region default
        private readonly ESCRAPODbContext escDb;

        private readonly IWebHostEnvironment henv;
     //   private object tblPersonRec;
        public LoginController(ESCRAPODbContext escDB, IWebHostEnvironment henv)
        {
            escDb = escDB;
            this.henv = henv;
        }
        #endregion default
        //------put it in every new controller ends---


        public IActionResult ChangePassword()
        {
            return View();
        }

        public JsonResult chgpasswdJson(string Pemail, string Ppassword, string pnpassword)
        {
            PersonMaster personmaster = new PersonMaster();
            personmaster = escDb.PersonMasters.Where(q => q.Pemail == Pemail && q.Ppassword == Ppassword).FirstOrDefault();

            if (personmaster != null)
            {
                personmaster.Ppassword = pnpassword;
                escDb.Entry(personmaster).State = EntityState.Modified;

                return Json("Success");
            }
            else
            {
                return Json("Invalid email id and password");

            }
        }
        public IActionResult ForgetPassword()
        {
            return View();
        }
        public IActionResult Home()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(IFormCollection frm)
        {
            var Email = Convert.ToString(frm["pemail"]);
            var Passwd = Convert.ToString(frm["Ppassword"]);
            var rdFound = escDb.PersonMasters.Where(pm => pm.Pemail == Email && pm.Ppassword == Passwd).FirstOrDefault();

            if (rdFound != null) // record is found
            {
                if (rdFound.Proleid == 1)

                {
                    return RedirectToAction("AdminHome", "Admin");
                }



                else if (rdFound.Proleid == 2)

                {
                    return RedirectToAction("UserHome", "User", new { rdFound.Pid});
                }
                else if (rdFound.Proleid == 3)

                {
                    return RedirectToAction("TransporterHome", "Transporter", new { rdFound.Pid });
                }
            }
            else
            {
                TempData["ErrMsg"] = "Invalid email or Password";
            }


            return View();
        }

        [HttpGet]
        public IActionResult SignupAsUser()
        {
            var qList = escDb.QuestionMasters.ToList();
            ViewBag.QuestionList = qList;
            return View();
        }

        [HttpPost]
        public IActionResult SignupAsUser(IFormCollection frm)
        {
            PersonMaster personmaster = new PersonMaster();
            personmaster.Pname = Convert.ToString(frm["Pname"]);
            personmaster.Paddress = Convert.ToString(frm["Paddress"]);
            personmaster.Pdob = Convert.ToString(frm["Pdob"]);
            personmaster.Pgender = Convert.ToString(frm["Pgender"]);
            personmaster.Pphone = Convert.ToString(frm["Pphone"]);
            personmaster.Pemail = Convert.ToString(frm["Pemail"]);
            personmaster.Ppassword = Convert.ToString(frm["Ppassword"]);
            personmaster.Pqid = Convert.ToInt32(frm["Pqid"]);
            personmaster.Panswer = Convert.ToString(frm["Panswer"]);
            personmaster.Proleid = 2;
            escDb.PersonMasters.Add(personmaster);
            escDb.SaveChanges();
            return RedirectToAction("Login");


        }
        public JsonResult CheckEmail(string Pemail)
        {
            var rdFound = escDb.PersonMasters.Where(q =>
            q.Pemail == Pemail).FirstOrDefault();
            if (rdFound != null)
            {
                return Json(false);
            }
            else {
                return Json(true);
            }
        }
        [HttpGet]
public IActionResult SignupAsTransporter()
        {
            var qList = escDb.QuestionMasters.ToList();
            ViewBag.QuestionList = qList;
            return View();
        }

        [HttpPost]
        public IActionResult SignupAsTransporter(PersonMaster personmaster,IFormCollection frm,IFormFile  file)
        {
            personmaster.Pqid = Convert.ToInt32(frm["Pqlist"]);
            personmaster.Proleid = 3;
            string uniqueImageName = null;
            if (file != null)
            {
           // C: \Users\RiyaSoni\source\repos\ESCRAPO\ESCRAPO\wwwroot\
                string uploadimgfoldername = Path.Combine(henv.WebRootPath, "images\\TransporterImages");
                uniqueImageName = Guid.NewGuid().ToString() + "_" + file.FileName;
                string finalPath = Path.Combine(uploadimgfoldername, uniqueImageName);
                file.CopyTo(new FileStream(finalPath, FileMode.Create));
            }
            personmaster.Pimage = "images\\TransporterImages\\" + uniqueImageName;
            escDb.PersonMasters.Add(personmaster);
            escDb.SaveChanges();
            return RedirectToAction("Login");
        }
        public IActionResult ForgetPasswordPost()
        {
            
            return View();
        }

    }
}
/*private object tblPersonRec;
*/