﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ESCRAPO.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ESCRAPO.Controllers
{
    public class TransporterController : Controller
    {
        //    public object escDb { get; private set; }
        #region default
        private readonly ESCRAPODbContext escDb;

        private readonly IWebHostEnvironment henv;


        public TransporterController(ESCRAPODbContext escDB, IWebHostEnvironment henv)
        {
            escDb = escDB;
            this.henv = henv;
        }
        #endregion default
        //------put it in every new controller ends---

        public IActionResult TransporterHome(int Pid)
            {
                HttpContext.Session.SetString("Perid", Convert.ToString(Pid));
                return View();
            }


        [HttpGet]
        public IActionResult TransporterComplain()
        {
            return View();
        }
        [HttpPost]
        public IActionResult TransporterComplain(IFormCollection frm)
        {

            ComplainMaster complainmaster = new ComplainMaster();
            complainmaster.Pid = Convert.ToInt32(HttpContext.Session.GetString("Perid"));
            complainmaster.ComplainDesc = Convert.ToString(frm["Cdetails"]);
            escDb.ComplainMasters.Add(complainmaster);
           
            escDb.SaveChanges();
            return RedirectToAction("TransporterComplainPost");

        }
        public IActionResult TransporterComplainPost()
        {
            return View();
        }
        public IActionResult TransporterFeedback()
        {
            return View();
        }

        #region drvDetails
        public IActionResult TransporterViewDriverDetails()
        {
            var drvList = escDb.DriverMasters.ToList();
            var areaList = escDb.AreaMasters.ToList();
            ViewBag.AreaList = areaList;
            return View(drvList);
        }

        [HttpGet]
        public IActionResult Adddriver()
        {
            var daList = escDb.AreaMasters.ToList();
            ViewBag.AreaList = daList;
            return View();
        }


        [HttpPost]
        public IActionResult Adddriver(DriverMaster drivermaster, IFormCollection frm, IFormFile fileImg, IFormFile fileLic)
        {
            drivermaster.DrvAid = Convert.ToInt32(frm["dalist"]);
            string uniqueImageName = null;
            if (fileImg != null)
            {
                // C: \Users\RiyaSoni\source\repos\ESCRAPO\ESCRAPO\wwwroot\
                string uploadimgfoldername = Path.Combine(henv.WebRootPath, "images\\DriverImages\\DrvImg");
                uniqueImageName = Guid.NewGuid().ToString() + "_" + fileImg.FileName;
                string finalPath = Path.Combine(uploadimgfoldername, uniqueImageName);
                fileImg.CopyTo(new FileStream(finalPath, FileMode.Create));
            }
            drivermaster.Drvimage = "images\\DriverImages\\DrvImg\\" + uniqueImageName;


            if (fileLic != null)
            {
                // C: \Users\RiyaSoni\source\repos\ESCRAPO\ESCRAPO\wwwroot\
                string uploadimgfoldername = Path.Combine(henv.WebRootPath, "images\\DriverImages\\DrvLic");
                uniqueImageName = Guid.NewGuid().ToString() + "_" + fileLic.FileName;
              string finalPath = Path.Combine(uploadimgfoldername, uniqueImageName);
                fileLic.CopyTo(new FileStream(finalPath, FileMode.Create));
            }
            drivermaster.DrvLicimage = "images\\DriverImages\\DrvLic\\" + uniqueImageName;

            escDb.DriverMasters.Add(drivermaster);
            escDb.SaveChanges();
            return RedirectToAction("TransporterViewDriverDetails");
        }



        [HttpGet]
        public IActionResult TransporterEditdriver(int Drvid)
        {
            var drved = escDb.DriverMasters.Where(dm => dm.Drvid == Drvid).FirstOrDefault();
            return View(drved);
        }

        [HttpPost]
        public IActionResult TransporterEditdriver(DriverMaster drivermaster, IFormCollection frm, IFormFile fileImg, IFormFile fileLic)
        {
            drivermaster.DrvAid = Convert.ToInt32(frm["dalist"]);
            string uniqueImageName = null;
            if (fileImg != null)
            {
                // C: \Users\RiyaSoni\source\repos\ESCRAPO\ESCRAPO\wwwroot\
                string uploadimgfoldername = Path.Combine(henv.WebRootPath, "images\\DriverImages\\DrvImg");
                uniqueImageName = Guid.NewGuid().ToString() + "_" + fileImg.FileName;
                string finalPath = Path.Combine(uploadimgfoldername, uniqueImageName);
                fileImg.CopyTo(new FileStream(finalPath, FileMode.Create));
            }
            drivermaster.Drvimage = "images\\DriverImages\\DrvImg\\" + uniqueImageName;


            if (fileLic != null)
            {
                // C: \Users\RiyaSoni\source\repos\ESCRAPO\ESCRAPO\wwwroot\
                string uploadimgfoldername = Path.Combine(henv.WebRootPath, "images\\DriverImages\\DrvLic");
                uniqueImageName = Guid.NewGuid().ToString() + "_" + fileLic.FileName;
                string finalPath = Path.Combine(uploadimgfoldername, uniqueImageName);
                fileImg.CopyTo(new FileStream(finalPath, FileMode.Create));
            }
            drivermaster.DrvLicimage = "images\\DriverImages\\DrvLic\\" + uniqueImageName;

            escDb.Entry(drivermaster).State = EntityState.Modified;
            escDb.SaveChanges();
            return RedirectToAction("TransporterViewDriverDetails");
            
        }

        public IActionResult TransporterRemovedriver(int Drvid)
        {
            
            var removeDr = escDb.DriverMasters.Where(dm => dm.Drvid == Drvid).FirstOrDefault();
            escDb.Entry(removeDr).State = EntityState.Deleted;
            escDb.SaveChanges();
            return RedirectToAction("TransporterViewDriverDetails");
        }
        #endregion drvDetails

        public IActionResult TransporterLogout()
        {
            return RedirectToAction("Home", "Login");
        }






    }
}
