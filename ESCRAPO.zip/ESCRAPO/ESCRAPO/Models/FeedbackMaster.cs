﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ESCRAPO.Models
{
    public class FeedbackMaster
    {
        //bydefault first key is considered as primary key, but if you want you can explicity define a key as pk
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Fid { get; set; }
       
        [Required]
        public int Pid { get; set; }

        [Column(TypeName = "varchar(550)")]
        [Required]  //for notnull
        public string FeedbackDesc { get; set; }

        [Column(TypeName = "varchar(150)")]
        [Required]  //for notnull
        public string FeedbackDateTime { get; set; }


        [Column(TypeName = "varchar(10)")]
        [Required]  //for notnull
        public string FeedbackExperience { get; set; }
    }
}
