﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ESCRAPO.Models;

namespace ESCRAPO.Models
{
    public class ESCRAPODbContext : DbContext
    {
        public ESCRAPODbContext(DbContextOptions<ESCRAPODbContext> options) : base(options)

        {

        }

        public DbSet<AreaMaster> AreaMasters  { get; set; }
        public DbSet<ComplainMaster>ComplainMasters { get; set; }
        public DbSet<FeedbackMaster> FeedbackMasters { get; set; }
        public DbSet<PersonMaster> PersonMasters { get; set; }

        public DbSet<ProductCategoryMaster> ProductCategoryMasters { get; set; }

        public DbSet<ProductSubCategoriesMasters> ProductSubCategoriesMasters { get; set; }
        public DbSet<QuestionMaster> QuestionMasters { get; set; }

        public DbSet<DriverMaster> DriverMasters { get; set; }

        public DbSet<AddtoCartMaster> AddtoCartMasters { get; set; }
    }


}
