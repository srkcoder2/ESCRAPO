﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ESCRAPO.Models
{
    public class QuestionMaster
    {
        //bydefault first key is considered as primary key, but if you want you can explicity define a key as pk
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Qid { get; set; }
        [Column(TypeName = "varchar(350)")]


        [Required]  //for notnull
        public string QuestionText { get; set; }


    }
}
