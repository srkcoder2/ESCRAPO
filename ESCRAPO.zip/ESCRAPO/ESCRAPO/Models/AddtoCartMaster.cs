﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ESCRAPO.Models
{
    public class AddtoCartMaster
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Cartid { get; set; }
      
        [Required]  //for notnull
        public int Uid { get; set; }
       
        [Required]  //for notnull
        public int SCid { get; set; }
       
        [Required]
        public int SCqty { get; set; }

    }


}
