﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ESCRAPO.Models
{
    public class DriverMaster
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Drvid { get; set; }


        [Column(TypeName = "varchar(100)")]
        [Required]  //for notnull
        public string Drvname { get; set; }


        [Column(TypeName = "varchar(50)")]
        public string Drvaddress { get; set; }


        [Column(TypeName = "varchar(50)")]
        public string Drvdob { get; set; }


        [Column(TypeName = "varchar(10)")]
        public string Drvgender { get; set; }


        [Column(TypeName = "varchar(15)")]
        [Required]
        public string Drvphone { get; set; }


        [Column(TypeName = "varchar(100)")]
        [Required]  //for notnull

        public string DrvVehicleNumber { get; set; }
        [Column(TypeName = "varchar(250)")]
        public string Drvimage { get; set; }
        [Column(TypeName = "varchar(250)")]

        public string DrvLicimage { get; set; }


        [Required]
        public int DrvAid { get; set; }

        public int TransId { get; set; }
    }
}
