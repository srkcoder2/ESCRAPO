﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ESCRAPO.Migrations
{
    public partial class FifthMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Catimage",
                table: "ProductCategoryMasters",
                type: "varchar(250)",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Catimage",
                table: "ProductCategoryMasters");
        }
    }
}
