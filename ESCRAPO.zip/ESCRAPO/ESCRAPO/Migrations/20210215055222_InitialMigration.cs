﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ESCRAPO.Migrations
{
    public partial class InitialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AreaMasters",
                columns: table => new
                {
                    Aid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Areaname = table.Column<string>(type: "varchar(100)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AreaMasters", x => x.Aid);
                });

            migrationBuilder.CreateTable(
                name: "ComplainMasters",
                columns: table => new
                {
                    Cid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Pid = table.Column<int>(type: "int", nullable: false),
                    ComplainDesc = table.Column<string>(type: "varchar(500)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ComplainMasters", x => x.Cid);
                });

            migrationBuilder.CreateTable(
                name: "DriverMasters",
                columns: table => new
                {
                    Drvid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Drvname = table.Column<string>(type: "varchar(100)", nullable: false),
                    Drvaddress = table.Column<string>(type: "varchar(50)", nullable: true),
                    Drvdob = table.Column<string>(type: "varchar(500)", nullable: true),
                    Drvgender = table.Column<string>(type: "varchar(10)", nullable: true),
                    Drvphone = table.Column<string>(type: "varchar(15)", nullable: false),
                    DrvVehicleNumber = table.Column<string>(type: "varchar(100)", nullable: false),
                    Drvimage = table.Column<string>(type: "varchar(50)", nullable: true),
                    DrvLicimage = table.Column<string>(type: "varchar(250)", nullable: true),
                    DrvAid = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DriverMasters", x => x.Drvid);
                });

            migrationBuilder.CreateTable(
                name: "FeedbackMasters",
                columns: table => new
                {
                    Fid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Pid = table.Column<int>(type: "int", nullable: false),
                    FeedbackDesc = table.Column<string>(type: "varchar(550)", nullable: false),
                    FeedbackDateTime = table.Column<string>(type: "varchar(150)", nullable: false),
                    FeedbackExperience = table.Column<string>(type: "varchar(10)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FeedbackMasters", x => x.Fid);
                });

            migrationBuilder.CreateTable(
                name: "PersonMasters",
                columns: table => new
                {
                    Pid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Pname = table.Column<string>(type: "varchar(100)", nullable: false),
                    Paddress = table.Column<string>(type: "varchar(50)", nullable: true),
                    Pdob = table.Column<string>(type: "varchar(10)", nullable: true),
                    Pgender = table.Column<string>(type: "varchar(10)", nullable: true),
                    Pphone = table.Column<string>(type: "varchar(15)", nullable: false),
                    Pemail = table.Column<string>(type: "varchar(100)", nullable: false),
                    Ppassword = table.Column<string>(type: "varchar(50)", nullable: false),
                    Pimage = table.Column<string>(type: "varchar(250)", nullable: true),
                    Pqid = table.Column<int>(type: "int", nullable: false),
                    Panswer = table.Column<string>(type: "varchar(150)", nullable: true),
                    Proleid = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PersonMasters", x => x.Pid);
                });

            migrationBuilder.CreateTable(
                name: "ProductCategoryMasters",
                columns: table => new
                {
                    Catid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Catname = table.Column<string>(type: "varchar(250)", nullable: false),
                    Catimage = table.Column<string>(type: "varchar(250)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductCategoryMasters", x => x.Catid);
                });

            migrationBuilder.CreateTable(
                name: "ProductSubCategoriesMasters",
                columns: table => new
                {
                    SCid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SCname = table.Column<string>(type: "varchar(100)", nullable: false),
                    SCimage = table.Column<string>(type: "varchar(500)", nullable: false),
                    SCpriceperunit = table.Column<int>(type: "int", nullable: false),
                    Catid = table.Column<int>(type: "int", nullable: false),
                    SCDesc = table.Column<string>(type: "varchar(1000)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductSubCategoriesMasters", x => x.SCid);
                });

            migrationBuilder.CreateTable(
                name: "QuestionMasters",
                columns: table => new
                {
                    Qid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    QuestionText = table.Column<string>(type: "varchar(350)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QuestionMasters", x => x.Qid);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AreaMasters");

            migrationBuilder.DropTable(
                name: "ComplainMasters");

            migrationBuilder.DropTable(
                name: "DriverMasters");

            migrationBuilder.DropTable(
                name: "FeedbackMasters");

            migrationBuilder.DropTable(
                name: "PersonMasters");

            migrationBuilder.DropTable(
                name: "ProductCategoryMasters");

            migrationBuilder.DropTable(
                name: "ProductSubCategoriesMasters");

            migrationBuilder.DropTable(
                name: "QuestionMasters");
        }
    }
}
